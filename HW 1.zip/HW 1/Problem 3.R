# STA 141 HW 1 
# Problem 3

# Write a function that takes a sequence (vector) of 0 or 1 as input 
#       and returns the starting location of all subsequences 
#       that start and end with prespecified motifs (vectors of 0’s and 1’s).

# function name - Loc_1
# Two arguements - X is the input vector, which contains 0's or 1's
#                - S is the starting motif
#                - E is the ending motif
# Output is a numeric vector containing the starting location of 
#       all subsequences that start and end with prespecified motifs
#       If no run is found, return 0 as the location.

Loc_1 <- function(X, S, E) {
        # if starting or ending motif is longer than the input sequence
        #       return an error message
        if ( min(length(S), length(E)) > length(X) ) {
                stop("The starting or ending motif should be smaller or as equal to the input vector")
        }
        
        location = numeric(0)
        j = 0
        for (i in 1: ( length(X)-length(S)+1 ) ) {
                # check if the subsequence contains the starting motif
                #       X[i:(i+length(S)-1)] is the starts of the subsequence
                check1 = ( X[i:(i+length(S)-1)] == S)
                if (sum(check1) == length(S)) {
                        # check if the subsequence contains the ending motif
                        for (l in i:( length(X)-length(E)+1 ) ) {
                                check2 = ( X[l:(l+length(E)-1)] == E)
                                if ( sum(check2) == length(E) ) {
                                        j = j + 1
                                        location[j] = i
                                        break
                                }
                        }
                }
        }
        return(location)
}