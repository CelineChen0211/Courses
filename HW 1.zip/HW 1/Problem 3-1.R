# STA 141 HW 1 
# Problem 3

# Write a function that takes a sequence (vector) of 0 or 1 as input 
#       and returns the starting location of all subsequences 
#       that start and end with prespecified motifs (vectors of 0’s and 1’s).

# function name - Loc
# Two arguements - X is the input vector, which contains 0's or 1's
#                - S is the starting motif
#                - E is the ending motif
# Output is a data frame containing the starting locations and the length 
#       of all subsequences that start and end with prespecified motifs.
#       First column is the starting point.
#       Second column is the length of subsequence.
#       If no run is found, return 0 as the location.

Loc <- function(X, S, E) {
        # if starting or ending motif is longer than the input sequence
        #       return an error message
        if ( min(length(S), length(E)) > length(X) ) {
                stop("The starting or ending motif should be smaller or as equal to the input vector")
        }
        
        location = data.frame("Starting locations" = 0, "Length of subsequence" = 0)
        j = 0
        for (n in max(length(S), length(E)): length(X) ) {
                # subsetting the vector with length n
                for (i in 1: (length(X)-n+1) ) {
                        # subvector with length n
                        Y = X[i:(i+n-1)]
                        # subsetting the start motif
                        W = Y[1:length(S)]
                        # subsetting the last motif
                        Z = Y[(n-length(E)+1):n]
                        check1 = ( W == S )
                        check2 = ( Z == E )
                        if (sum(check1) == length(S) && sum(check2) == length(E)) {
                                j = j + 1
                                location[j,] = c(i, n)
                        }
                                
                }
                
        }
        return(location)
}