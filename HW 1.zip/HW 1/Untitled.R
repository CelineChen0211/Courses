# STA 141 HW 1 
# Problem 2

# Write a function that takes a sequence (vector) of 0 or 1 as input
#       returns the starting locations of runs of 0’s and runs of 1’s,
#       where the length of a run is set to an integer K ≥ 1

# function name - Loc_0and1
# Two arguements - X is the input vector, which contains 0's or 1's
#                - K is the length of a run
Loc_0and1 <- function(X, K){
        location = c(0,0)
        
        
        for (i in 1:length(X)-K+1) {
                if (X[i] == 0) {
                        check = ( X[i, i+K-1] == 0)
                        if (sum(check) == K) location[1] = i
                }
                else {
                        check = ( X[i, i+K-1] == 1)
                        if (sum(check) == K) location[2] = i 
                }
        }
       
        return(location)
}