# Write a function that takes a sequence (vector) of 0 or 1 as input 
#       and returns the starting location of all subsequences with specified length
#       that start and end with prespecified motifs (vectors of 0’s and 1’s).

# function name - Loc
# Two arguements - X is the input vector, which contains 0's or 1's
#                - S is the starting motif
#                - E is the ending motif
#                - n is length of the subsequence required
# Output is a numeric vector containing the starting location of 
#       all subsequences that start and end with prespecified motifs
#       If no run is found, return 0 as the location.

Loc_n <- function(X, S, E, n) {
        # if starting or ending motif is longer than the input sequence
        #       return an error message
        if ( min(length(S), length(E)) > length(X) ) {
                stop("The starting or ending motif should be smaller or as equal to the input vector")
        }
        
        location = numeric(0)
        j = 0
        # subsetting the vector with length n
        for (i in 1: (length(X)-n+1) ) {
                # subvector with length n
                Y = X[i:(i+n-1)]
                # subsetting the start motif
                W = Y[1:length(S)]
                # subsetting the last motif
                Z = Y[(n-length(E)+1):n]
                check1 = ( W == S )
                check2 = ( Z == E )
                if (sum(check1) == length(S) && sum(check2) == length(E)) {
                        j = j + 1
                        location[j] = i
                        }
                }
        return(sort(location))
}